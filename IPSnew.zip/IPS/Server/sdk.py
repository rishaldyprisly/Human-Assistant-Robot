#install paho mqtt library for python before using the code. You can find that library inside the zip file.  

import paho.mqtt.client as mqttClient
import time
import simplejson
import urllib2


#Please change the device serial according to the serial key given by the consumer portal
DEVICE_SERIAL = "2774176010478590";

#topics for sending events and receiving action messages . DON'T CHANGE
SUBSCRIBED_TOPIC = "genericDevice/" + DEVICE_SERIAL + "/+/sub"
EVENT_TOPIC = "generic_brand_796generic_device1/common"
response = urllib2.urlopen("http://localhost:9090/states")


def connect(tries):
    global client
    if tries < 1:
        return

    try:
		client.connect(broker_address, port, KEEPALIVE)
		print("Connected to " + broker_address + " : " + port)

    except:
        print("Can't connect to the server")
        time.sleep(5)
        tries = tries - 1
        connect(tries)
		
		
def on_connect(client, userdata, flags, rc):
    print "Subscribing to topic " + SUBSCRIBED_TOPIC
    client.subscribe(SUBSCRIBED_TOPIC)
 
def on_message(client, userdata, message):
	print "Message received: "  + message.payload
	do_actions(message.payload)
	
def publish_message(message):
	client.publish(EVENT_TOPIC,message,0,False)

	
#====================================================================================================================================================================	
def send_events():
	
	message = simplejson.load(response)
#	print data[0]
	#create this function to send some events to the backend. You should create a message format like this
	"""Eg :{
				"mac":"6655591876092787",
				"eventName":"eventOne",
				"state":"none",
				"eventOne":{
					"ev1Value1":30
				}
			}
	
	"""
	#Should call this function to send events. Pass your message as parameter
	publish_message(message)

#====================================================================================================================================================================
#====================================================================================================================================================================	
def do_actions(message):
	#Create this function according to your actions. you will receive a message something like this
	""" Eg : {
				"action":"actionOne",
				"param":{
					"ac1Value1":"1110" ,
					"parentMac":"6655591876092787",
					"ac1Value4":"port:03",
					"ac1Value5":"on",
					"mac":"6655591876092787",
					"ac1Value2":"2220",
					"ac1Value3":"567776"
				}
			} """

#=====================================================================================================================================================================	
#Connected = False   #global variable for the state of the connection
 
broker_address= "mqtt.flexiot.xl.co.id"  #Broker address
port = "1883"                         #Broker port
user = "rabbit"                    #Connection username
password = "rabbit"            #Connection password
KEEPALIVE = 6;
 
client = mqttClient.Client("Python")               #create new instance
client.username_pw_set(user, password=password)    #set username and password
#client.connect(broker_address, port)                  #attach function to callback
#client.on_message= on_message                      #attach function to callback
client.publish(publish_message)
while 1:

    connect(5)
    client.loop_start()
    # TODO : Update to use a keyboard interrupt
    time.sleep(1000)
    client.loop_stop()
    client.disconnect()
