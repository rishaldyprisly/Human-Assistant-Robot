import simplejson
import urllib2
import pymysql

while True:
	response = urllib2.urlopen("http://localhost:9090/states")
	data = simplejson.load(response)
	print data[0]
#	print data[0]['name']
#	print data[0]['address']
#	print data[0]['location']
#	print data[0]['reader']
#	print data[0]['rssi']
#	print data[0]['type']

#
#	connection = pymysql.connect(host='localhost',
#                                     port=3306,
#                                     user='root',
#                                     password='',
#                                     db='ips',
#                                     charset='utf8mb4',
#                                     cursorclass=pymysql.cursors.DictCursor)
#

#	with connection.cursor() as cursor:
#        # Create a new record
#	        sql = 'INSERT INTO tracked (name, address, location, reader, rssi, type) VALUES (%s, %s, %s, %s, %s, %s)'
#	        cursor.execute(sql, (data[0]['name'], data[0]['address'], data[0]['location'], data[0]['reader'], data[0]['rssi'],data[0]['type']))

#	        connection.commit()
