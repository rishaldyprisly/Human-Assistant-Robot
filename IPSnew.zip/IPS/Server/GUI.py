from Tkinter import *
import tkFileDialog as filedialog
def mstore(text):
    file = open("file.txt", "w")            # Create file.txt
    file.write(text)                        # Write contents of mEntryname to file
    file.close()                            # Closes text file

def msearch():
    file = filedialog.askopenfilename()     # Stores file directory that user chose
    open_file = open(file, 'r')             # Opens file user chose
    print(open_file.read())                 # Displays contents in console
    open_file.close()                       # Closes text file

# Window Creation and Settings
window = Tk()
window.geometry('450x500')          
window.title('Form Test')

# Create Widgets
mTitle = Label (window,text='Heading Text',bg='white')
mDetail = Label (window,text='Flavour you can see',bg='white')
mFName = Label (window,text='Barcode',bg='white')
mEntryname = Entry(window)
# Runs mstore function when pressed (passing the contents of the entry box)
mSave = Button (window,text='Save',bg='white', command = lambda: mstore(mEntryname.get()))
# Runs msearch function when pressed
mSearch = Button (window,text='Search',bg='white', command = lambda: msearch())

# Render Widgets
mTitle.pack()
mDetail.pack()
mFName.pack()
mEntryname.pack()
mSave.pack()
mSearch.pack()

window.mainloop()
